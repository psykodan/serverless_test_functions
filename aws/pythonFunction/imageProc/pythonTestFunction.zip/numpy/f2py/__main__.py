# See http://cens.ioc.ee/projects/f2py2e/
from __future__ import division, print_function

from numpy.f2py.f2py2e import main

main()
